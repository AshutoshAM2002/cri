const service = require("./service.js");
const constants = require("../locales/constants.js");

const getCsiOverall = (req, res) => {
  let apiResponse = service.getDataForCsi(constants.CSI_OVERALL, req.body.filterRequest);
  sendResponse(apiResponse, res);
};

const getCsiData = (req, res) => {
  let apiResponse = service.getDataForCsi(constants.CSI_DATA, req.body.filterRequest);
  sendResponse(apiResponse, res);
};

const getCsiVoice = (req, res) => {
  let apiResponse = service.getDataForCsi(constants.CSI_VOICE, req.body.filterRequest);
  sendResponse(apiResponse, res);
};
const sendResponse = (apiResponse, res, next) => {
  apiResponse.then((result) => {
    res.status(200).json({ data: result });
  }).catch(err=>next(err));
};

module.exports = {
  getCsiOverall,
  getCsiData,
  getCsiVoice
};
