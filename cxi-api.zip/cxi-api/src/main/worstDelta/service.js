const constants = require("../locales/constants.js");
const dbUtil = require("../db/dbUtil.js");
const seperator = "_";

const getData = async function (searchKey, filterRequest) {
  var field = getSecondaryRedisKey(filterRequest);
  return dbUtil.getDataForWorstTabs(
    searchKey,
    constants.REDIS_KEY_WORST_DELTA_KEY,
    constants.VALUE_REDIS_KEY_WORST_DELTA,
    field,
    filterRequest.demo
  );
};

function getSecondaryRedisKey(filterRequest) {
  var field = filterRequest.endDate
    .concat(seperator)
    .concat(filterRequest.systemType);
  field = field.concat(seperator).concat(filterRequest.coreKPI);
  field = field.concat(seperator).concat(filterRequest.region);
  field = field.concat(seperator).concat(filterRequest.avgPercent);
  field = field.concat(seperator).concat(filterRequest.f1);
  return field;
}

module.exports = { getData };
