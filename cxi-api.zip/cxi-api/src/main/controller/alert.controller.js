const alertService = require("../service/alert.service");

async function createAlert(req, res, next) {
  alertService
    .createAlert(JSON.parse(req.body.payload), req.files, next)
    .then((val) => {
      res.status(200).json(val);
    })
    .catch((err) => next(err));
}

async function getAlerts(req, res, next) {
  alertService
    .getAlerts(req.body)
    .then((val) => {
      res.status(200).json(val);
    })
    .catch((err) => next(err));
}

async function shareAlert(req, res, next) {
  try {
    return res.send(await alertService.shareAlert(req.body));
  } catch (err) {}
}

async function getSmartCards(req, res, next) {
  alertService
    .getSmartCards(req.body)
    .then((val) => {
      res.status(200).json(val);
    })
    .catch((err) => next(err));
}

async function getMapView(req, res, next) {
  alertService
    .getMapView(req.body)
    .then((val) => {
      res.status(200).json(val);
    })
    .catch((err) => next(err));
}

module.exports = { createAlert, getAlerts, shareAlert, getSmartCards, getMapView};
