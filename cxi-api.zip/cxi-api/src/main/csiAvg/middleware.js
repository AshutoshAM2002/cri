// helper functions
const Joi = require('joi');
const validator = require("../middlewares/validator/requestValidator.js");
const createFilterSchema = function (req, res, next) {
    const schema = Joi.object({ "filterRequest" :{
        "startDate": Joi.string().required(),
        "endDate": Joi.string().required(),
        "region": Joi.string().required(),
        "systemType": Joi.array().required(),
        "callDuration": Joi.number().integer().required(),
        "dataVolume": Joi.number().integer().required(),
    }});
    validator.validateRequest(req, next, schema);
}
module.exports = {createFilterSchema};
