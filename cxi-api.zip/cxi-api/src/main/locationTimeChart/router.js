const express = require("express");
const router = express.Router();

const locationController = require("./controller.js");
const middleware = require("./middleware.js");

router.post("/search", middleware.createSearchSchema, locationController.search);
router.post("/chart", middleware.createChartSchema, locationController.chartData);
module.exports = router;