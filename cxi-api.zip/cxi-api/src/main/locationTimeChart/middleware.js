// helper functions
const Joi = require("joi");
const validator = require("../middlewares/validator/requestValidator.js");
const createChartSchema = function (req, res, next) {
  const schema = Joi.object({
    filterRequest: {
      startDate: Joi.string().required(),
      endDate: Joi.string().required(),
      systemType: Joi.array().required(),
      locations: Joi.array().required(),
      coreKPI: Joi.string().required(),
      callDuration: Joi.number().integer(),
      dataVolume: Joi.number().integer(),
    },
  });
  validator.validateRequest(req, next, schema);
};

const createSearchSchema = function (req, res, next) {
  const schema = Joi.object({
    filterRequest: {
      type: Joi.string().required(),
      searchText: Joi.string().required(),
    },
  });
  validator.validateRequest(req, next, schema);
};
module.exports = { createChartSchema, createSearchSchema };
