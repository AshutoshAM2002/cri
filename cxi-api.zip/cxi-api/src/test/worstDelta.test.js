process.env.NODE_ENV = "test";

const server = require("../main/app");
const chai = require("chai");
const chaiHttp = require("chai-http");

//Assertion
chai.should();
chai.use(chaiHttp);

const assert = chai.assert;

describe("Worst Area API", () => {
  let validFilterRequest = {
    filterRequest : {
      startDate: "20211213",
      endDate: "20211213",
      region: "ROA",
      systemType: "LTE",
      coreKPI:"CSI_OVERALL",
      f1 : 50,
      avgPercent:50
  }
};

let inValidFilterRequest = {
  filterRequest : {
    startDate: "20211213",
    endDate: "20211213",
    region: "ROA",
    systemType: "LTE",
    coreKPI:"CSI_OVERALL"
}
};


  it("Table View", (done) => {
    chai
      .request(server)
      .post("/api/v1/worstDelta/data")
      .send(validFilterRequest)
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });

  it("Table View with Invalid request", (done) => {
    chai
      .request(server)
      .post("/api/v1/worstDelta/data")
      .send(inValidFilterRequest)
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });

  it("Map Response ", (done) => {
    chai
      .request(server)
      .post("/api/v1/worstDelta/map")
      .send(validFilterRequest)
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });
  it("Map Response ", (done) => {
    chai
      .request(server)
      .post("/api/v1/worstDelta/chart")
      .send(validFilterRequest)
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });
});
