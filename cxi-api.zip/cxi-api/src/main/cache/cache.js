const redis = require("redis-mock");
const client = redis.createClient();
const util = require("util");
client.HGET = util.promisify(client.HGET);
client.exists = util.promisify(client.exists);
client.HSET = util.promisify(client.HSET);

const getCacheResponse = async (bastionKey, cacheKey) => {
  try {
    var isKeyExist = await client.exists(bastionKey);
    if (isKeyExist) {
      var cacheResult = await client.HGET(bastionKey, cacheKey);
      return cacheResult;
    }
    return null;
  } catch (err) {
    console.log("Error " + err);
  }
};

const getCacheObject = async (bastionKey) => {
  try {
    var isKeyExist = await client.exists(bastionKey);
    if (isKeyExist) {
      var cacheResult = await client.GET(bastionKey);
      return cacheResult;
    }
    return null;
  } catch (err) {
    console.log("Error " + err);
  }
};


const setCacheObject = (bastionKey, data) => {
  client.SET(bastionKey, JSON.stringify(data));
};
const setCacheResponse = (bastionKey, cacheKey, data) => {
  client.HSET(bastionKey,cacheKey, JSON.stringify(data));
};

module.exports = { getCacheResponse, setCacheResponse,getCacheObject ,setCacheObject};
