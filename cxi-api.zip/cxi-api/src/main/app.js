const express = require("express");
var cors = require("cors");
const app = express();
const ApiError = require('./middlewares/error/ApiError.js');
const apiErrorHandler = require('./middlewares/error/apiErrorHandler.js');
const db = require("./model");
global.__basedir = __dirname;

db.sequelize.sync();

const logger = require('./middlewares/logger/logger.js');
const httpLogger = require('./middlewares/logger/httpLogger.js');

const dotenv = require("dotenv");
dotenv.config();
const PORT = process.env.APP_PORT || 5000;
const router = require("./routes/v1Routes.js");
const constants = require("./locales/constants.js");

var corsOptions = { origin: ['http://ui.dev.docx.halo-telekom.com', 'http://localhost:8080',  'http://localhost:8082', 'http://ui.demo.docx.halo-telekom.com'], credentials: true};

// Handling Uncaught Exception
process.on('uncaughtException', err => {
  logger.error('Failed due to Uncaught exception.');
  logger.error(err);
});

app.use(cors(corsOptions));

// to convert json object into models
app.use(
  express.urlencoded({
    extended: true,
  })
);
app.use(express.json());
app.use(httpLogger);
//Routes

app.use('/uploads', express.static(constants.ALERT_UPLOAD_ROOT_PATH+"/"+constants.ALERT_UPLOAD_FOLDER));
app.use("/api/v1/", router);

// Handle unhandled routes
app.all('*', (req, res, next) => {
  logger.info(`${req.originalUrl} route not found`);
  next(ApiError.notFound(`${req.originalUrl} route not found`));
});

app.use(apiErrorHandler);
const server = app.listen(PORT, function () {
  console.log(`Listening on port ${PORT}`);
});

// Handling Unhandled Promise Rejection
process.on('unhandledRejection', err => {
  console.log(err);
  logger.error('Failed due to Unhandled promise rejection.');
  logger.error(err);
});

module.exports = app;
