module.exports = (sequelize, DataTypes) => {
  return sequelize.define("alert_images", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    alertId: {
      type: DataTypes.INTEGER,
      field: "alert_id",
      allowNull: false,
    },
    name: {
      type: DataTypes.STRING,
      field: "name",
      allowNull: false,
    },
    imgUrl: {
      type: DataTypes.STRING,
      field: "img_url",
      allowNull: false,
    },
  });
};
