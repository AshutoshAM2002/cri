const constants = require("../locales/constants.js");
const dbUtil = require("../db/dbUtil.js");

async function getDataForCsi(csiType, filterRequest) {
  var dataKey = formKey(csiType, filterRequest)
  return dbUtil.getCsiData(constants.REDIS_PLM_KEY, dataKey);
}

function formKey(csiType, filterRequest) {
  var seperator = "_";
  var defaultSystemTypeKey = "ALL";
  var key = filterRequest.startDate + seperator + filterRequest.endDate;
  filterRequest.systemType
    ? (key = key.concat(seperator).concat(filterRequest.systemType))
    : (key = key.concat(seperator).concat(defaultSystemTypeKey));
  key = key.concat(seperator).concat(csiType);
  return key;
}

module.exports = {
  getDataForCsi,
  formKey
};
