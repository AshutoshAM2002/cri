process.env.NODE_ENV = "test";
const assert = require("chai").assert;
const csiAvgService = require("../main/csiAvg/service.js");

describe("csiAvgService.service.js", () => {
    let filterRequest = {
        startDate: "20211213",
        endDate: "20211213",
        region: "THESSALIAS",
        systemType: ["LTE","GSM"],
        collDuration: 1200,
        dataVolume:500
      };
    it("csiAvgService.formKey()", () => {
        const response = csiAvgService.formKey("docx_avg_csi_key", "CSI_OVERALL",filterRequest);
        assert.isNotEmpty(response);
    });
  });