module.exports = {
  Admin: "ADM",
  Enginner: "ENG",
  Manager : "MNG"
};
