const GEO_JSON_FORMAT = '{"type":"FeatureCollection","features":[]}';
const FEATURES_JSON =
  '{"type":"Feature","geometry":{"type":"Point","coordinates":[27.8350515,36.6008592]},"properties":{"name":"SYMIX","code":"6301","csi_average":"85.0"}}';

function generateMapData(data, key) {
  var features = [];
  data.forEach((record) => {
    var feature = JSON.parse(FEATURES_JSON);
    if (record) {
      feature.properties.name = record.site_name;
      feature.properties.code = record.site_id;
      feature.properties.csi_average = record[key];
      feature.geometry.coordinates[0] = record.longitude;
      feature.geometry.coordinates[1] = record.latitude;
    }
    features.push(feature);
  });
  var geoJSON = JSON.parse(GEO_JSON_FORMAT);
  geoJSON.features = features;
  return geoJSON;
}

module.exports = { generateMapData };
