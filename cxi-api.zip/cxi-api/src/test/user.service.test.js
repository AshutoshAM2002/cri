process.env.NODE_ENV = "test";
const userService = require("../main/service/user.service");
const sinon = require("sinon");
const { expect } = require("chai");
const db = require("../main/model");
const User = db.user;
const UserRole = db.userRole;
describe("User Service", () => {
  let userStub;
  let user;
  let updateStub;
  let deleteStub;
  let createStub;
  beforeEach(() => {
    user = [
      {
        id: 1,
        name: "Arpit Jain",
        email: "arpit.jain@t-systems.com",
        roles: [{ id: 1, roleCode: "ADM", roleName: "ADMIN" }],
        confirmed: true,
        isActive: true,
      },
    ];
  });
  afterEach(() => {
    userStub.restore();
    if (updateStub) {
      updateStub.restore();
    }
    if (deleteStub) {
      deleteStub.restore();
    }
    if (createStub) {
      createStub.restore();
    }
  });
  it("Find All users", async () => {
    userStub = await sinon.stub(User, "findAll").returns(user);
    const users = await userService.getAllUsers();
    expect(userStub.calledOnce).to.be.true;
    expect(users).not.empty;
    expect(users[0].id).equals(1);
  });
  it("Find User By Username ", async () => {
    userStub = await sinon.stub(User, "findOne").returns(user[0]);
    const fetchedUser = await userService.getUserByUserName("test");
    expect(userStub.calledOnce).to.be.true;
    expect(fetchedUser).not.empty;
    expect(fetchedUser.id).equals(1);
  });
  it("Find users by ids", async () => {
    userStub = await sinon.stub(User, "findAll").returns(user);
    const users = await userService.getUsersByIds([1]);
    expect(userStub.calledOnce).to.be.true;
    expect(users).not.empty;
    expect(users[0].id).equals(1);
  });

  it("Find User By Email ", async () => {
    userStub = await sinon.stub(User, "findOne").returns(user[0]);
    const fetchedUser = await userService.getUserByEmail("test");
    expect(userStub.calledOnce).to.be.true;
    expect(fetchedUser).not.empty;
    expect(fetchedUser.id).equals(1);
  });

  it("Confirm Username ", async () => {
    userStub = await sinon.stub(User, "update").returns(true);
    const confirmed = await userService.confirmUser("test");
    expect(userStub.calledOnce).to.be.true;
    expect(confirmed).equals(true);
  });

  it("Roles Update", async () => {
    updateStub = await sinon.stub(User, "update");
    deleteStub = await sinon.stub(UserRole, "destroy");
    createStub = await sinon.stub(UserRole, "create");
    userStub = await sinon.stub(User, "findAll").returns(user);
    const confirmed = await userService.roleUpdateForUsers(user);
    console.log(confirmed);
    expect(userStub.calledOnce).to.be.true;
    expect(confirmed).not.empty;
  });

  it("Roles Update with no roles", async () => {
    let emptyRole = (user = [
      {
        id: 1,
        name: "Arpit Jain",
        email: "arpit.jain@t-systems.com",
        confirmed: true,
        isActive: true,
      },
    ]);
    updateStub = await sinon.stub(User, "update");
    deleteStub = await sinon.stub(UserRole, "destroy");
    createStub = await sinon.stub(UserRole, "create");
    userStub = await sinon.stub(User, "findAll").returns(user);
    const confirmed = await userService.roleUpdateForUsers(emptyRole);
    console.log(confirmed);
    expect(userStub.calledOnce).to.be.true;
    expect(updateStub.calledOnce).to.be.true;
    expect(confirmed).not.empty;
  });
});
