module.exports = {
    HOST: "172.17.44.18",
    USER: "root",
    PASSWORD: "Csi2022Csi#@!",
    DB: "docx-csi",
    dialect: "mysql",
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  };