const cache = require("../cache/cache.js");
const repo = require("../db/repo.js");
const logger = require("../middlewares/logger/logger.js");
const constants = require("../locales/constants.js");
const mapUtil = require("../_helpers/mapUtil.js");

const getData = async function (bastionKey, field, isDemo) {
  try {
    if (isDemo === "true") {
      bastionKey = bastionKey.concat("_demo");
    }
    var cacheResponse = await cache.getCacheResponse(bastionKey, field);
    if (cacheResponse) {
      return JSON.parse(cacheResponse);
    }
    return repo.get(bastionKey, field);
  } catch (err) {
    logger.error(
      "Failed to either to load the data from redis or parse the JSON from the cache response."
    );
    logger.error(err);
  }
};

const getBucket = async function (bastionKey, field, isDemo) {
  let key = bastionKey.toLowerCase();
  if (field) {
    key = key + field.toLowerCase();
  }
  try {
    if (isDemo === "true") {
      key = key.concat("_demo");
    }
    var cacheResponse = await cache.getCacheResponse(key);
    if (cacheResponse) {
      return JSON.parse(cacheResponse);
    }
    return repo.getObject(key);
  } catch (err) {
    logger.error(
      "Failed to either to load the data from redis or parse the JSON from the cache response."
    );
    logger.error(err);
  }
};

const getCsiData = async function (redisKey, dataKey) {
  let key = redisKey.toLowerCase() + dataKey.toLowerCase();

  let data = await repo.getObject(key);
  if (data) {
    return data.sort((a, b) => (a.xLabel > b.xLabel ? 1 : -1));
  }
  return [];
};

const getDataForWorstTabs = async function (
  searchKey,
  mainRedisKey,
  valueRedisKey,
  field,
  isDemo
) {
  var result = [];
  var secKeyToFetchRealData = await getBucket(mainRedisKey, field, isDemo);
  if (secKeyToFetchRealData) {
    var data = await getBucket(
      valueRedisKey,
      secKeyToFetchRealData.value_key,
      isDemo
    );
    if (data) {
      result = data[searchKey];
      if (searchKey === constants.SITE_ID_DATA) {
        result = mapUtil.generateMapData(
          result,
          constants.MAP_PROP_CSI_AVERAGE
        );
      }
    }
    return result;
  }
  return result;
};

module.exports = { getData, getCsiData, getDataForWorstTabs, getBucket };
