const db = require("../model");
const Role = db.role;
const Op = db.Sequelize.Op;

exports.findAll = async () => {
  try {
    return await Role.findAll({ raw: true });
  } catch (err) {
    res.status(500).send({
      message: err.message || "Some error occurred while retrieving roles.",
    });
  }
};
