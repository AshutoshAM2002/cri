const service = require("./service.js");
const constants = require("../locales/constants.js");
const logger = require("../middlewares/logger/logger.js");

const getCsiOverall = (req, res, next) => {
  let data = service.getCsiAvgData(constants.CSI_OVERALL, req.body.filterRequest);
  sendResponse(data, res, next);
};

const getCsiData = (req, res, next) => {
  let data = service.getCsiAvgData(constants.CSI_DATA,req.body.filterRequest);
  sendResponse(data, res, next);
};

const getCsiVoice = (req, res, next) => {
  let data = service.getCsiAvgData(constants.CSI_VOICE,req.body.filterRequest);
  sendResponse(data, res, next);
};

const sendResponse = (apiResponse, res, next) => {
  apiResponse.then((result) => {
    res.status(200).json({ data: result });
  }).catch(err=>{
    logger.error("Error "+err); next(err)});
};

module.exports = {
  getCsiOverall,
  getCsiData,
  getCsiVoice
};
