process.env.NODE_ENV = "test";

const server = require("../main/app");
const chai = require("chai");
const chaiHttp = require("chai-http");

//Assertion
chai.should();
chai.use(chaiHttp);

const assert = chai.assert;

describe("ALERT API", () => {
  let validFilterRequest = {
      startDate: "20211213",
      endDate: "20220526",
      region: "ALL",
      systemType: "LTE",
      csiValue : 50
};

let inValidFilterRequest = {
    startDate: "20211213",
    endDate: "20211213",
    region: "ROA",
    systemType: "LTE",
    coreKPI:"CSI_OVERALL"
};


  it("Map View", (done) => {
    chai
      .request(server)
      .post("/api/v1/getMapView")
      .send(validFilterRequest)
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });

  it("Map View with Invalid request", (done) => {
    chai
      .request(server)
      .post("/api/v1/getMapView")
      .send(inValidFilterRequest)
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });

  it("Smard Card Response ", (done) => {
    chai
      .request(server)
      .post("/api/v1/getAlertSmartCards")
      .send(validFilterRequest)
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });
  it("Get Alerts Response ", (done) => {
    chai
      .request(server)
      .post("/api/v1/getAlerts")
      .send(validFilterRequest)
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });
});
