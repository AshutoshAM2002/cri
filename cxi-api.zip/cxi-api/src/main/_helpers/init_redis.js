const redis = require("redis");
const logger = require('../middlewares/logger/logger.js');

const client = redis.createClient({
  port: 6379,
  host: "10.1.20.187",
});

client.on("error", function (err) {
  logger.error("Database connection error encountered");
  logger.error(err);
});

client.on("connect", function (error) {
  console.log("Connection Estabilished");
});

client.on("ready", () => {
  console.log("client connected to redis and ready to use..");
});

client.on("end", () => {
  console.log("client disconnected from redis..");
});

const getConnection = function () {
  return client;
};

module.exports = {
  getConnection,
  setupFilesAfterEnv: ["./jest.setup.redis-mock.js"],
};
