const ldapService = require("../service/ldap.service");
exports.getLdapUsers = async function (req, res) {
    let users = await ldapService.searchUsers(req.params.criteria);
    res.send(users);
};
