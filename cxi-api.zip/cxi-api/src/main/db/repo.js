const redis = require("../_helpers/init_redis.js");
const cache = require("../cache/cache.js");
const logger = require("../middlewares/logger/logger.js");
const redisClient = redis.getConnection();

const util = require("util");
redisClient.HGET = util.promisify(redisClient.HGET);
redisClient.EXISTS = util.promisify(redisClient.exists);
redisClient.HGETALL = util.promisify(redisClient.HGETALL);
redisClient.SET = util.promisify(redisClient.SET);
redisClient.GET = util.promisify(redisClient.GET);

function isDBConnected() {
  return redisClient.connected;
}
const get = async function (bastionKey, field) {
  var result = "NO DATA";
  try {
    var isExist = await redisClient.EXISTS(bastionKey);
    if (isExist) {
      result = await redisClient.HGET(bastionKey, field);
      if (result == null) {
        logger.info(
          "Either data for redis key " +
            bastionKey +
            " with field " +
            field+" is missing or it failed to fetch it."
        );
      }
      if (result) {
        result = JSON.parse(result);
        cache.setCacheResponse(bastionKey, field, result);
      }
    }
  } catch (err) {
    logger.error("Error in Redis GET CALL " + err);
  }
  return result;
};

const getAll = async function (bastionKey) {
  var isExist = await redisClient.EXISTS(bastionKey);
  if (isExist) {
    return await redisClient.HGETALL(bastionKey);
  }
  return "NO DATA";
};

const getObject = async function (bastionKey) {
  var result = "NO DATA";
  try {
    var isExist = await redisClient.EXISTS(bastionKey);
    if (isExist) {
      result = await redisClient.GET(bastionKey);
      if (result == null) {
        logger.info(
          "Either data for redis key " +
            bastionKey +
            " with field " +
            field+" is missing or it failed to fetch it."
        );
      }
      if (result) {
        result = JSON.parse(result);
        cache.setCacheResponse(bastionKey, field, result);
      }
    }
  } catch (err) {
    logger.error("Error in Redis GET CALL " + err);
  }
  return result;
};


const set = async function (bastionKey, field, value) {
  var userInfo = JSON.stringify(value);
  var res = await redisClient.HSET(bastionKey, field, userInfo);
  if (res === 1) {
    cache.setCacheResponse(bastionKey, field, userInfo);
    return "SUCCESS";
  }
  return false;
};
module.exports = { get, getAll, set , isDBConnected,getObject};
