const constants = require("../locales/constants.js");
const dbUtil = require("../db/dbUtil.js");
const mapUtil = require("../_helpers/mapUtil.js");
const seperator = "_";

const getDBResponse = async function (searchKey, filterRequest) {
  var field = getSecondaryRedisKey(filterRequest);
  if (searchKey === constants.SITE_ID_DATA) {
    return getMapData(
      filterRequest.worstCsiInput,
      constants.REDIS_KEY_WORST_CELLS_KEY,
      constants.VALUE_REDIS_KEY_WORST_CELLS,
      field,
      filterRequest.demo
    );
  }
  var result = await dbUtil.getDataForWorstTabs(
    searchKey,
    constants.REDIS_KEY_WORST_CELLS_KEY,
    constants.VALUE_REDIS_KEY_WORST_CELLS,
    field,
    filterRequest.demo
  );
  result = result.slice(0, filterRequest.worstCsiInput);
  return result;
};

const getMapData = async function (
  worstCsiInput,
  mainRedisKey,
  valueRedisKey,
  field,
  isDemo
) {
  var result = [];
  var secKeyToFetchRealData = await dbUtil.getBucket(mainRedisKey, field, isDemo);
  if (secKeyToFetchRealData) {
    var data = await dbUtil.getBucket(
      valueRedisKey,
      secKeyToFetchRealData.value_key,
      isDemo
    );
    if (data) {
      var tableData = data[constants.TABLE_DATA];
      if (tableData.length > 0) {
        tableData = tableData.slice(0, worstCsiInput);
        var siteIdData = data[constants.SITE_ID_DATA];
        tableData.forEach((csi) => {
          result.push(siteIdData.find((s) => s.site_id == csi.site_id));
        });
        result = mapUtil.generateMapData(result, constants.MAP_PROP_CSI_AVERAGE);
      }
    }
    return result;
  }
  return result;
};

function getSecondaryRedisKey(filterRequest) {
  var field = filterRequest.startDate + seperator + filterRequest.endDate;
  field = field.concat(seperator).concat(filterRequest.systemType);
  field = field.concat(seperator).concat(filterRequest.coreKPI);
  field = field.concat(seperator).concat(filterRequest.region);
  field = field.concat(seperator).concat(filterRequest.avgPercent);
  return field;
}

module.exports = { getDBResponse };
