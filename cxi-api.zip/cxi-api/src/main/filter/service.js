const repo = require("../db/repo.js");
const constants = require("../locales/constants.js");
const catchAsyncErrors = require("../middlewares/error/catchAsyncErrors.js");

const getRedisData = catchAsyncErrors(async function () {
  var data = await repo.getAll(constants.REDIS_KEY_FITLER_API);
  return filterResponse(data);
});
const filterResponse = function (redisData) {
  var filterArray = [];
  var allSystemTypes = [];
  for (const [key, value] of Object.entries(redisData)) {
    if (key.startsWith("region")) {
      var obj = JSON.parse(value);
      let fs = {};
      fs.region = key.split(":")[1];
      fs.systemType = obj.systemtype;
      filterArray.push(fs);
    }
    if (key.startsWith("systemtype")) {
      allSystemTypes.push(key.split(":")[1]);
    }
  }
  let allFltr = {};
  allFltr.region = "ALL";
  allFltr.systemType = allSystemTypes;
  filterArray.push(allFltr);
  filterArray.sort((a,b)=>(a.region > b.region)?1:-1);
  return filterArray;
};
module.exports = { getRedisData, filterResponse };
