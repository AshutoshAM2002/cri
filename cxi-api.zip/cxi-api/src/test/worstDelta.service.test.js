process.env.NODE_ENV = "test";
const assert = require("chai").assert;
const worstDeltaService = require("../main/worstDelta/service.js");
const repo = require("../main/db/repo.js");
let sinon = require("sinon");
var path = require("path");
var file = path.join(__dirname, "./resource/worstAreaTable.json");
var data = path.join(__dirname, "./resource/tableData.json");
var mapData = path.join(__dirname, "./resource/siteId.json");
const constants = require("../main/locales/constants.js");

let filterRequest = {
  startDate: "20211213",
  endDate: "20211213",
  region: "ROA",
  systemType: "LTE",
  coreKPI: "CSI_OVERALL",
  f1: 20,
  avgPercent: 50,
};

describe("worstDelta.service.js", () => {
  let getStub;
  let disconnectStub;
  beforeEach(() => {
    getStub = sinon.stub(repo, "get");
    disconnectStub = sinon.stub(repo, "isDBConnected");
    disconnectStub.returns(true);
  });
  afterEach(() => {
    disconnectStub.restore();
    getStub.restore();
  });
  it("Stub worstDelta.getData for Table ()", () => {
    filterRequest.demo = true;
    getStub.onFirstCall().returns(require(data)).onSecondCall().returns(require(file));
    const response = worstDeltaService.getData(constants.TABLE_DATA,filterRequest);
    response.then((val) => {
      assert.isNotEmpty(val);
    });
  });

  it("Stub worstArea.getData for Map ()", () => {
    getStub.onFirstCall().returns(require(data)).onSecondCall().returns(require(mapData));
    const response = worstDeltaService.getData(constants.SITE_ID_DATA, filterRequest);
    response.then((val) => {
      assert.isNotEmpty(val);
    });
  });
});
