process.env.NODE_ENV = "test";
const assert = require("chai").assert;
const filterService = require("../main/filter/service.js");
var path = require("path");
var file = path.join(__dirname, "./resource/filter.json");

describe("filter.service.js", () => {
    it("filter.filterResponse()", () => {
        var data = {"region:EMA": "{\"systemtype\":[\"LTE\",\"GSM\"]}", "systemtype:GSM": "{\"region\":[\"NAG\",\"CMA\",\"CRE\",\"EMA\",\"STE\",\"IPR\",\"THE\",\"PEL\",\"ION\",\"TSL\",\"ATH\",\"WMA\",\"SAG\",\"ROA\"]}"}
        const response = filterService.filterResponse(data);
        assert.isNotEmpty(response);
    });
  });