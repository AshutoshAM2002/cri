const express = require("express");
const router = express.Router();

const areaController = require("./controller.js");
const middleware = require("./middleware.js");

router.post("/avgcsicell", middleware.validateFilterRequest, areaController.getAvgCSIPerCellId);
router.post("/coreKPI", middleware.validateFilterRequest, areaController.getCoreKPIData);
router.post("/data", middleware.validateFilterRequest, areaController.getPrefectureData);
router.post("/map",middleware.validateFilterRequest, areaController.getMapData);


module.exports = router;
