const express = require("express");
const router = express.Router();

const plmController = require("./controller.js");
const middleware = require("../csiArea/middleware.js");


router.post("/csiOverall", middleware.validateFilterRequest, plmController.getCsiOverall);
router.post("/csiVoice", middleware.validateFilterRequest, plmController.getCsiVoice);
router.post("/csiData",middleware.validateFilterRequest, plmController.getCsiData);
module.exports = router;