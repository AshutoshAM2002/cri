const loginService = require("./login.service");
const jwt = require("jsonwebtoken");
const ApiError = require("../middlewares/error/ApiError");
const logger = require("../middlewares/logger/logger.js");
const config = require("../config.json");

const loginViaLdap = async (req, res, next) => {
  try {
    let issuer = req.protocol + "://" + req.get("host");
    let token = await loginService.byPassLogin(req.body, issuer);
    res.status(200).send(token);
  } catch (err) {
    logger.error(err);
    next(
      ApiError.unAuthorize(
        "Authentication failed. Please enter valid credentials."
      )
    );
  }
};
module.exports = { loginViaLdap };
