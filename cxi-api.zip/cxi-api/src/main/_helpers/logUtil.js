
const logMessage = function(timestamp, methodName, code, message, description, errStack ){
    var errMessage = {};
    errMessage.timestamp = timestamp;
    errMessage.methodName = methodName;
    errMessage.code = code;
    errMessage.message = message;
    errMessage.description = description;
    errMessage.errStack = errStack;

    return errMessage;
}

module.exports = {logMessage}