const ApiError = require("./ApiError");

module.exports = (err, req, res, next) => {

    let error =
    process.env.NODE_ENV === "development"
      ? { message: err.message, statusCode: err.statusCode, timeStamp: new Date(), stack: err.stack }
      : { message: err.message, statusCode: err.statusCode, timeStamp: new Date() };

  if (err instanceof ApiError) {
    res.status(err.statusCode).json({error});
    return;
  }
  let errResponse = { ...err };

  errResponse.statusCode = err.statusCode || 500;
  errResponse.message = err.message || "Internal Server Error ";

  // Handling database Validation Error
  if (err.name === "ValidationError") {
    const message = Object.values(err.errors).map((value) => value.message);
    errResponse = ApiError.badRequest(message);
  }
  if (err.name === "MulterError") {
    const message = err.message + ", max file size is allowed 2 MB only.";
    errResponse = ApiError.badRequest(message);
  }
  // Handling Wrong JWT token error
  if (err.name === "JsonWebTokenError") {
    errResponse = ApiError.internal("JSON Web token is invalid. Try Again!");
  }

  // Handling Expired JWT token error
  if (err.name === "TokenExpiredError") {
    errResponse = ApiError.internal("JSON Web token is expired. Try Again!");
  }

  // Handle databse duplicate key error
  if (err.code === 11000) {
    const message = `Duplicate ${Object.keys(err.keyValue)} entered.`;
    errResponse = ApiError.badRequest(message);
  }

  error = {message: errResponse.message, statusCode: errResponse.statusCode, timeStamp: new Date(),}
  res.status(errResponse.statusCode).json({error});
  return;
};
