const db = require("../model");
const User = db.user;
const UserRole = db.userRole;

const Op = db.Sequelize.Op;
const mailService = require("./mail.service");
const constants = require("../locales/constants");

exports.getAllUsers = async function () {
  try {
    return await User.findAll({
      where: { confirmed: true },
      include: [
        {
          model: db.role,
          as: "roles",
          through: { attributes: [] },
        },
      ],
    });
  } catch (err) {}
};

exports.getUserByUserName = async function (userName) {
  try {
    return await User.findOne({
      where: { userName: userName },
      include: [
        {
          model: db.role,
          as: "roles",
          through: { attributes: [] },
          raw: true,
        },
      ],
    });
  } catch (err) {}
};

exports.roleUpdateForUsers = async function (users) {
  try {
    let ids = [];
    await roleUpdateForUser(ids, users);
    return await this.getUsersByIds(ids);
  } catch {}
};

exports.getUsersByIds = async function (ids) {
  try {
    return await User.findAll({
      where: {
        id: ids,
      },
      include: [
        {
          model: db.role,
          as: "roles",
          through: { attributes: [] },
        },
      ],
    });
  } catch (err) {}
};

exports.createUsersFromLdap = async function (users) {
  try {
    let createdUsers = [];
    for (let user of users) {
      let existingUser = await this.getUserByEmail(user.email);
      if (!existingUser) {
        const newUser = await User.create(
          {
            confirmed: false,
            isActive: true,
            firstName: user.firstName,
            lastName: user.lastName,
            email: user.email,
            userName: user.userName,
            name: user.name,
          },
          { raw: true }
        );
        newUser["roles"] = user["roles"];
        await updateRole(newUser);
        const replace = { recipientEmail: newUser.email };
        await mailService.sendMail(
          constants.FROM_MAIL_ID,
          newUser.email,
          constants.INVITATION_SUBJECT,
          "invitation",
          replace
        );
        createdUsers.push(newUser.email);
      }
    }
    return createdUsers;
  } catch (err) {}
};

exports.getUserByEmail = async function (email) {
  try {
    return await User.findOne({
      where: { email: email },
      raw: true,
    });
  } catch (err) {}
};

exports.confirmUser = async function (email) {
  await User.update(
    {
      confirmed: true,
    },
    {
      where: {
        email: email,
      },
    }
  );
  return true;
};

async function roleUpdateForUser(ids, users) {
  for (let i = 0; i < users.length; i++) {
    let user = users[i];
    await updateUser(user);
    ids.push(user.id);
    if (user.roles && user.roles.length > 0) {
      await deleteUserRoleMapping(user.id);
      await updateRole(user);
    } else if (!user.roles || user.roles.length <= 0) {
      await deleteUserRoleMapping(user.id);
    }
  }
}
async function updateRole(user) {
  for (let j = 0; j < user.roles.length; j++) {
    let element = user.roles[j];
    await UserRole.create({
      role_id: element.id,
      user_id: user.id,
    });
  }
}

async function updateUser(user) {
  if (user.isActive != null && user.isActive != undefined) {
    await User.update(
      {
        isActive: user.isActive,
      },
      {
        where: {
          id: user.id,
        },
      }
    );
  }
}
async function deleteUserRoleMapping(ids) {
  let options = {
    where: {
      userId: ids,
    },
  };
  await UserRole.destroy(options);
}
