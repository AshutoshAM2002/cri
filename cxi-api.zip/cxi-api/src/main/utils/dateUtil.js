// it will return date in YYYY-MM-DD format.
// input should be in YYYYMMDD format
function getYYYYMMDD(date) {
    return (
      date.substring(0, 4) +
      "-" +
      date.substring(4, 6) +
      "-" +
      date.substring(6, 8)
    );
  }

  module.exports = {getYYYYMMDD};