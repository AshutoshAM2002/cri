const db = require("../model");
const EmailTemplate = db.emailTemplate;
const Op = db.Sequelize.Op;

exports.findByName = async (name) => {
  try {
    let emailTemplate = await EmailTemplate.findOne({
      where: { templateName: name },
      raw: true,
    });
    return emailTemplate.template;
  } catch (err) {
    res.status(500).send({
      message: err.message || "Some error occurred while retrieving templates.",
    });
  }
};
