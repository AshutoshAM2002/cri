# docx-api
1. Deployed on AWS.
2. Backend Development on Node.js
3. Redis NoSql Database used.
4. Gard page
5. SonarQube 

# AWS Endpoint
  http://dev-docx-rest-api.eu-central-1.elasticbeanstalk.com/api/v1

# Redis Configuration
  **HOST** = 10.1.20.187

  **PORT** = 6379

# Node.js
  **package.json** 
    - Used to download require dependecies for Development

  **app.js**
    - Main file to start the application
  
  **routes/v1Routes.js**
    - Configure the all API's routes in this file.

# How to run the application locally 
    npm install
    npm start

# How to generate the Sonar report
    1. npm run test
    2. npm run coverage-lcov **Generates the cobertura-coverage.xml file**
    3. sonar-scanner -Dsonar.projectKey=docx-api -Dsonar.sources=./ -Dsonar.host.url="${SONAR_HOST_URL}" -Dsonar.login="${SONAR_LOGIN_TOKEN}" -Dsonar.cobertura.reportPath=./coverage/cobertura-coverage.xml

# Gard Page 
  
  1. Redis keys details store on below gard page link. 
     Redis keys used to read the data. 

    https://gard.telekom.de/gardwiki/display/HH/Redis+Keys
  
  2. Architecture Digram 
  
    https://gard.telekom.de/gardwiki/display/HH/Dashboard+Analytics+Workflow

# To view the Sonar report
   **URL**:         http://highv.sonar.halo-telekom.com:9000/
   
   **PROJECT KEY**: docx-api
