const db = require("../model");
const fs = require("fs");
const path = require("path");
const Alert = db.alert;
const Image = db.alertImages;
const ApiError = require("../middlewares/error/ApiError.js");
const logger = require("../middlewares/logger/logger.js");
const constants = require("../locales/constants.js");
const dataUtil = require("../utils/dataUtil.js");
const dateUtil = require("../utils/dateUtil.js");
const { Op } = require("sequelize");
const mailService = require("./mail.service");
const repo = require("../db/repo.js");
var priorityMap = new Map([
  ["None", 5],
  ["Low", 4],
  ["Medium", 3],
  ["High", 2],
  ["Critical", 1],
]);

exports.createAlert = async function (alert, files, next) {
  const t = await db.sequelize.transaction();
  try {
    const sDate = dateUtil.getYYYYMMDD(alert.startDate);
    const eDate = dateUtil.getYYYYMMDD(alert.endDate);

    const todayDate = new Date().toISOString().slice(0, 10);
    const priorityId = priorityMap.get(alert.priority);

    const newAlert = await Alert.create(
      {
        title: alert.title,
        description: alert.description,
        priority: alert.priority,
        priorityValue: priorityId,
        status: constants.ALERT_STATUS_CREATED,
        kpi: alert.kpi,
        region: alert.region,
        prefecture: alert.prefecture,
        dimos: alert.dimos,
        site: alert.site,
        startDate: sDate,
        endDate: eDate,
        systemType: alert.systemType,
        csiValue: alert.csiValue,
        createdBy: alert.createdBy,
        createdDate: todayDate,
      },
      {transaction:t},
      { raw: true }
    );
    await addImages(newAlert.id, files, t);
    await t.commit();
    return newAlert;

  } catch (err) {
    await t.rollback();
    logger.error("Error occured while creating the ALERT - " + err);
    throw ApiError.internal(
      "Unable to Process your request, Please try after some time."
    );
  }
};

exports.getAlerts = async function (alert) {
  try {
    const sDate = dateUtil.getYYYYMMDD(alert.startDate);
    const eDate = dateUtil.getYYYYMMDD(alert.endDate);
    let whereClause = getWhereClause(alert, sDate, eDate);
   
    let data = await Alert.findAll({ where: whereClause });
    return Array.from(data).sort((a, b) => dataUtil.sortByKeyInAscOrder(a, b, "priorityValue"));
  } catch (err) {
    logger.error("Error occured while getting all alerts - " + err);
    throw ApiError.internal(
      "Unable to Process your request, Please try after some time."
    );
  }
};

async function addImages(id, files, t) {
  const imagePath = await createDirectoryForAlert(id);
  if (imagePath) {
    for (let j = 0; j < files.length; j++) {
      const fileName = files[j].originalname;
      const imageUrl = imagePath + "/" + fileName;
      const fileContents = Buffer.from(files[j].buffer, "base64");
      fs.writeFileSync(imageUrl, fileContents);
      await Image.create({
        alertId: id,
        name: fileName,
        imgUrl: imageUrl,
      },{transaction:t});
    }
  }
}

async function createDirectoryForAlert(folderName) {
  let filepath = path.join(constants.ALERT_UPLOAD_ROOT_PATH, constants.ALERT_UPLOAD_FOLDER+folderName);
  fs.mkdirSync(filepath, { recursive: true }, (error) => {
    if (error) {
      logger.error(error);
      return null;
    } else {
      logger.info("New Directory created successfully !!");
    }
  });
  return filepath;
}

exports.shareAlert = async function (users) {
  try {
    let shareAlert = [];
    for (let user of users) {
      await mailService.sendMail(
        constants.FROM_MAIL_ID,
        user.email,
        constants.NEW_ALERT_SUBJECT,
        "sharealert",
        null
      );
      shareAlert.push(user.email);
    }

    return shareAlert;
  } catch (err) {}
};

exports.getSmartCards = async function (alert) {
  try {
    const sDate = dateUtil.getYYYYMMDD(alert.startDate);
    const eDate = dateUtil.getYYYYMMDD(alert.endDate);

    const whereClause = getWhereClause(alert, sDate, eDate);
    const totalAlerts = await Alert.findAll({ where: whereClause });
    const alertsOverLast7Days = await getLastWeekAlerts(alert);
    return await getSmartCardRespons(totalAlerts, alertsOverLast7Days);
  } catch (err) {
    logger.error("Error occured while getting all alerts - " + err);
    throw ApiError.internal(
      "Unable to Process your request, Please try after some time."
    );
  }
};


exports.getMapView = async function (filterRequest) {
  const alerts = await this.getAlerts(filterRequest);
  const baseData = await repo.get(
    constants.REDIS_KEY_MAP_REGION,
    constants.REGION_ALL
  );
  if (baseData && alerts && alerts.length >0) {
    for(let feature of baseData.features){
      if (feature && feature.properties) {
        await addAlertDetailsInFeatureProperties(feature, alerts, filterRequest.region);
    }
    }
  }
  return baseData;
};

async function getSmartCardRespons(totalAlerts, alertsOverLast7Days) {
  if(totalAlerts && alertsOverLast7Days){
    const totalAlertsRes = getTotalAlertsResponse(
      totalAlerts.length,
      alertsOverLast7Days.length
    );
    const newAlertsRes = getNewAndResolvedAlertsResponse(
      totalAlerts,
      alertsOverLast7Days,
      constants.ALERT_STATUS_CREATED,
      constants.SMART_CARD_LABEL_NEW
    );
    const resolvedAlertsRes = getNewAndResolvedAlertsResponse(
      totalAlerts,
      alertsOverLast7Days,
      constants.ALERT_STATUS_RESOLVED,
      constants.SMART_CARD_LABEL_RESOLVED
    );
    const criticalAlertRes = getCriticalAlertsResponse(
      totalAlerts,
      alertsOverLast7Days
    );
    return [totalAlertsRes, newAlertsRes, resolvedAlertsRes, criticalAlertRes];
  }
  return [];
}

async function getLastWeekAlerts(alert){

  const sDate = dateUtil.getYYYYMMDD(alert.startDate);

  let startDate = new Date(sDate);
  startDate.setDate(startDate.getDate() - 7);

  let endDate = new Date(sDate);
  endDate.setDate(endDate.getDate() - 1);

  const whereClauseForLast7Days = getWhereClause(alert, startDate.toISOString().split("T")[0], endDate.toISOString().split("T")[0]);

  return await Alert.findAll({
    where: whereClauseForLast7Days,
  });
}

async function addAlertDetailsInFeatureProperties(feature, regionAlerts, region) {

  let isRegionSelected = false;
  
  const alerts = regionAlerts.filter((alert)=> {
      if(feature.properties.code === alert.region){
        isRegionSelected = true;
        return alert;
      }
  });

  const totalAlertCount = alerts.length;

  const newAlertCount = getAlertCount(alerts, constants.ALERT_STATUS_CREATED);

  const criticalAlertCount =  getAlertCount(alerts, constants.SMART_CARD_LABEL_CRITICAL);

  const resolvedAlertCount = getAlertCount(alerts, constants.ALERT_STATUS_RESOLVED);

  feature.properties["total"] = constants.REGION_ALL === region ? totalAlertCount :  isRegionSelected ? totalAlertCount : -1;
  feature.properties["new"] = constants.REGION_ALL === region ? newAlertCount : isRegionSelected ? newAlertCount : -1;
  feature.properties["critical"] = constants.REGION_ALL === region ? criticalAlertCount : isRegionSelected ? criticalAlertCount : -1;
  feature.properties["resolved"] = constants.REGION_ALL === region ? resolvedAlertCount : isRegionSelected ? resolvedAlertCount : -1;
}

function getAlertCount(regionAlerts, label) {
  if(constants.SMART_CARD_LABEL_CRITICAL === label){
    return getFilteredAlertListCount(regionAlerts);
  }
  return regionAlerts.filter((alert)=>{
    return alert.status === label;
  }).length;
}

function getPercentage(countOfAlerts, countOfAlertsOverLast7Days) {
  const diff = countOfAlerts - countOfAlertsOverLast7Days;
  if (countOfAlerts == 0) {
    return 0;
  } 
  return (diff / countOfAlerts) * 100;
}

function getWhereClause(alert, sDate, eDate) {
  let wClause = {
    region: alert.region,
    system_type: alert.systemType,
    csi_value: { [Op.lte]: alert.csiValue },
    created_date: { [Op.gte]: sDate, [Op.lte]: eDate },
  };
  if(alert.region == constants.REGION_ALL){
    delete wClause.region;
  }
  return wClause;
}

//Total Alerts
function getTotalAlertsResponse(countOfAlerts, countOfAlertsOverLast7Days) {
  const percentage = getPercentage(countOfAlerts, countOfAlertsOverLast7Days);
  return {
    label: constants.SMART_CARD_LABEL_TOTAL_ALERTS,
    value: countOfAlerts,
    percentage: percentage,
  };
}

// New Alerts & Resolved Alerts
function getNewAndResolvedAlertsResponse(
  totalAlerts,
  alertsOverLast7Days,
  status,
  label
) {
  const filteredAlerts = totalAlerts.filter((alert) => {
    return alert.status == status;
  });
  const filteredAlertsOverLast7Days = alertsOverLast7Days.filter((
    alert) => {
    return alert.status == status;
  });
  const percentage = getPercentage(
    filteredAlerts.length,
    filteredAlertsOverLast7Days.length
  );
  return { label: label, value: filteredAlerts.length, percentage: percentage };
}

//Critical Alerts
function getCriticalAlertsResponse(totalAlerts, alertsOverLast7Days) {
  const totalAlertsCount = getFilteredAlertListCount(totalAlerts);
  const percentage = getPercentage(
    totalAlertsCount,
    getFilteredAlertListCount(alertsOverLast7Days)
  );
  return {
    label: constants.SMART_CARD_LABEL_CRITICAL,
    value: totalAlertsCount,
    percentage: percentage,
  };
}

function getFilteredAlertListCount(alerts){
  return alerts.filter((alert) => {
    return (alert.priorityValue == 1 && alert.status != constants.ALERT_STATUS_RESOLVED);
  }).length;
}
