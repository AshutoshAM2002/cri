module.exports = (sequelize, DataTypes) => {
  return sequelize.define("user", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    firstName: {
      type: DataTypes.STRING,
      field: "first_name",
    },
    lastName: {
      type: DataTypes.STRING,
      field: "last_name",
    },
    userName: {
      type: DataTypes.STRING,
      field: "user_name",
    },
    name: {
      type: DataTypes.STRING,
      field: "name",
    },
    email: {
      type: DataTypes.STRING,
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      field: "is_active",
    },
    confirmed: {
      type: DataTypes.BOOLEAN,
    },
  });
};
