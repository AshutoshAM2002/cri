process.env.NODE_ENV = "test";
const loginService = require("../main/auth/login.service.js");
const sinon = require("sinon");
const userService = require("../main/service/user.service");
const { expect } = require("chai");

describe("Login Service", () => {
  let userStub;
  let user = {
    id: 1,
    name: "Arpit Jain",
    email: "arpit.jain@t-systems.com",
    roles: [{ id: 1, roleCode: "ADM", roleName: "ADMIN" }],
    confirmed: true,
    isActive: true,
  };
  let issuer = "http://localhost:8080";
  beforeEach(() => {});
  afterEach(() => {
    userStub.restore();
  });
  it("should do the login.", async () => {
    const request = { username: "YXJwaXQ=", password: "YWRtaW4=" };
    userStub = sinon.stub(userService, "getUserByUserName").resolves(user);
    const token = await loginService.loginViaLdap(request, issuer);
    expect(userStub.calledOnce).to.be.true;
    expect(token).not.empty;
  });

  it("Invalid credentials", async () => {
    const request = { username: "YXJwaXQ=", password: "abc=" };
    try {
      await loginService.loginViaLdap(request, issuer);
    } catch (e) {
      expect(e["lde_message"]).equal("Invalid Credentials");
    }
  });

  it("User does not exisits.", async () => {
    const request = { username: "YXJwaXQ=", password: "YWRtaW4=" };
    userStub = sinon.stub(userService, "getUserByUserName").resolves({});

    try {
      await loginService.loginViaLdap(request, issuer);
    } catch (e) {
      expect(e.message).equal("UserNotFound");
    }
  });
});
