process.env.NODE_ENV = "test";
const assert = require("chai").assert;
const alertService = require("../main/service/alert.service.js");
const repo = require("../main/db/repo.js");
const db = require("../main/model");
let sinon = require("sinon");
var path = require("path");
var file = path.join(__dirname, "./resource/baseData.json");
var data = path.join(__dirname, "./resource/alerts.json");

const filterRequest = {
  startDate: "20211213",
  endDate: "20220526",
  region: "ALL",
  systemType: "LTE",
  csiValue: 60,
};

const filterReqRegionSelected = {
    startDate: "20211213",
    endDate: "20220526",
    region: "KRITIS",
    systemType: "LTE",
    csiValue: 60,
  };
  

describe("alert.service.js", () => {
  let getStub;
  let disconnectStub;
  let findAllStub;
  beforeEach(()=>{
    getStub = sinon.stub(repo, "get");
    findAllStub = sinon.stub(db.alert, "findAll");
    disconnectStub = sinon.stub(repo, "isDBConnected");
    disconnectStub.returns(true)
  });
  afterEach(() => {
    disconnectStub.restore();
    getStub.restore();
    findAllStub.restore();
  });
  it("Stub alert.getMapView ()", () => {
    getStub.returns(require(file));
    findAllStub.returns(require(data));
    const response = alertService.getMapView(filterRequest);
    response.then((val) => {
      assert.isNotEmpty(val);
    });
  });

  it("Stub alert.getSmartCards ()", () => {
    findAllStub.onFirstCall().returns(require(data)).onSecondCall().returns([]);
    const response = alertService.getSmartCards(filterRequest);
    response.then((val) => {
      assert.isNotEmpty(val);
    });
  });

  it("Stub alert.getAlerts ()", () => {
    findAllStub.returns(require(data));
    const response = alertService.getAlerts(filterReqRegionSelected);
    response.then((val) => {
      assert.isNotEmpty(val);
    });
  });

});
