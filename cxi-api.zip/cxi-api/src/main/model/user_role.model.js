module.exports = (sequelize, DataTypes) => {
  return sequelize.define("user_role", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
    },
    userId: {
      type: DataTypes.INTEGER,
      field: "user_id",
    },
    roleId: {
      type: DataTypes.INTEGER,
      field: "role_id",
    },
  });
};
