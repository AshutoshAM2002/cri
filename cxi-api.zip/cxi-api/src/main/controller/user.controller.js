const userService = require("../service/user.service");

async function findAll(req, res) {
  res.send(await userService.getAllUsers());
}

async function updateRole(req, res) {
  return res.send(await userService.roleUpdateForUsers(req.body));
}
async function createUserFromLdap(req, res) {
  return res.send(await userService.createUsersFromLdap(req.body));
}
async function confirmUser(req,res){
  return res.send(await userService.confirmUser(req.query.email));
}
module.exports = {
  findAll,
  updateRole,
  createUserFromLdap,
  confirmUser
};
