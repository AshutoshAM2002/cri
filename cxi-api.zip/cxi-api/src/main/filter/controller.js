const service = require("./service.js");
const getFilters = (req, res) => {
  var apiResponse =  service.getRedisData();
  apiResponse.then((val)=>{
    res.status(200).json({
      data: val,
    });
  })
};

module.exports = { getFilters };
