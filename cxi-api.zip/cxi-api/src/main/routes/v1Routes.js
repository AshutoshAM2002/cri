const express = require("express");
const router = express.Router();

const loginRoute = require("../auth/login.route.js");
const csiAreaRoute = require("../csiArea/router.js");
const filterRoute = require("../filter/router.js");
const plmRoute = require("../plm/router.js");
const worstAreaRoute = require("../worstArea/router.js");
const worstDeltaRoute = require("../worstDelta/router.js");
const csiAvgRoute = require("../csiAvg/router.js");
const locationRoute = require("../locationTimeChart/router.js");
const userCon = require("../controller/user.controller");
const roleCon = require("../controller/role.controller");
const validator = require("../middlewares/validator/requestValidator");
const ldapController = require("../controller/ldap.controller");
const mailController = require("../controller/mail.controller");
const alertController = require("../controller/alert.controller");
const authorize = require("../_helpers/authorize");
const verifyToken = require("../_helpers/verifyToken");
const Role = require("../_helpers/role");
router.use(
  "/csiArea",
  verifyToken,

  authorize([Role.Admin, Role.Enginner, Role.Manager]),
  csiAreaRoute
);
router.use("/login", loginRoute);
router.use("/filters", verifyToken, filterRoute);
router.use(
  "/plm",
  verifyToken,
  authorize([Role.Admin, Role.Enginner, Role.Manager]),
  plmRoute
);
router.use(
  "/worstArea",
  verifyToken,

  authorize([Role.Admin, Role.Enginner]),
  worstAreaRoute
);
router.use(
  "/worstDelta",
  verifyToken,

  authorize([Role.Admin, Role.Enginner]),
  worstDeltaRoute
);
router.use(
  "/csiAvg",
  verifyToken,

  authorize([Role.Admin, Role.Enginner, Role.Manager]),
  csiAvgRoute
);
router.use(
  "/location",
  verifyToken,

  authorize([Role.Admin, Role.Enginner]),
  locationRoute
);

router.get("/user", verifyToken, authorize([Role.Admin]), userCon.findAll);
router.put("/user", verifyToken, authorize([Role.Admin]), userCon.updateRole);
router.post(
  "/user",
  validator.validateCreateUserRequest,
  verifyToken,
  authorize([Role.Admin]),
  userCon.createUserFromLdap
);

router.get("/role", verifyToken, authorize([Role.Admin]), roleCon.findAll);

router.get(
  "/ldap/users/:criteria",
  verifyToken,
  authorize([Role.Admin,Role.Enginner,Role.Manager]),
  ldapController.getLdapUsers
);
router.get(
  "/mail",
  verifyToken,
  authorize([Role.Admin, Role.Enginner]),
  mailController.sendMail
);
router.get("/user/confirm", userCon.confirmUser);

router.post(
  "/alert/share",
  verifyToken,
  validator.validateShareAlert,
  alertController.shareAlert
);
router.post(
  "/alert",
  verifyToken,
  validator.uploadFile.array("files"),
  validator.validateAlertRequest,
  alertController.createAlert
);
router.post(
  "/getAlerts",
  verifyToken,
  validator.validateGetAlertsRequest,
  alertController.getAlerts
);
router.post(
  "/getAlertSmartCards",
  verifyToken,
  validator.validateGetAlertsRequest,
  alertController.getSmartCards
);
router.post("/getMapView" , verifyToken, validator.validateGetAlertsRequest, alertController.getMapView);
module.exports = router;
