process.env.NODE_ENV = "test";

const server = require("../main/app");
const chai = require("chai");
const chaiHttp = require("chai-http");

const repo = require("../main/db/repo.js");
let sinon = require("sinon");
var path = require("path");
var file = path.join(__dirname, "./resource/avgCSI.json");

//Assertion
chai.should();
chai.use(chaiHttp);

const assert = chai.assert;

describe("CSI AVG API", () => {
  let getAllStub;
  let disconnectStub;
  beforeEach(() => {
    getAllStub = sinon.stub(repo, "getAll");
    disconnectStub = sinon.stub(repo, "isDBConnected");
    disconnectStub.returns(true);
  });
  afterEach(() => {
    disconnectStub.restore();
    getAllStub.restore();
  });

  let validFilterRequest = {
    filterRequest: {
      startDate: "20211213",
      endDate: "20211213",
      region: "THESSALIAS",
      systemType: ["LTE"],
      callDuration:1200,
      dataVolume:500
    },
  };
  let InValidFilterRequest = {
    filterRequest: {
      startDate: "20211213",
      endDate: "20211213",
      systemType: ["LTE"],
      callDuration:1200,
      dataVolume:"500"
    },
  };

  it("CSI AVG API Overall", (done) => {
    getAllStub.usingPromise().resolves(require(file));
    chai
      .request(server)
      .post("/api/v1/csiAvg/csiOverall")
      .send(validFilterRequest)
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });

  it("CSI AVG API Voice", (done) => {
    validFilterRequest.csiType = "voice";
    chai
      .request(server)
      .post("/api/v1/csiAvg/csiVoice")
      .send(InValidFilterRequest)
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });

  it("CSI AVG API Data", (done) => {
    validFilterRequest.csiType = "data";
    chai
      .request(server)
      .post("/api/v1/csiAvg/csiData")
      .send(validFilterRequest)
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });
});
