process.env.NODE_ENV = "test";

const server = require("../main/app");
const chai = require("chai");
const chaiHttp = require("chai-http");

//Assertion
chai.should();
chai.use(chaiHttp);

const assert = chai.assert;

describe("CSI Area API", () => {
  let validFilterRequest = {
    filterRequest: {
      startDate: "20211213",
      endDate: "20211213",
      region: "ROA",
      systemType: "LTE",
    },
  };

  let InvalidFilterRequest = {
    filterRequest: {
      startDate: "",
      endDate: "2021-12-02",
    },
  };
  let NullFilterRequest = {
    filterRequest: "null",
  };


  it("Table Chart Report View", (done) => {
    chai
      .request(server)
      .post("/api/v1/csiArea/avgcsicell")
      .send(validFilterRequest)
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });

  it("Core KPI's ", (done) => {
    chai
      .request(server)
      .post("/api/v1/csiArea/coreKPI")
      .send(validFilterRequest)
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });

  it("Invalid Request for Core KPI's ", (done) => {
    chai
      .request(server)
      .post("/api/v1/csiArea/coreKPI")
      .send(InvalidFilterRequest)
      .then((err, response) => {
        assert.equal(response.status, "400");
      });
    done();
  });
  it("Invalid Request for Table Chart ", (done) => {
    chai
      .request(server)
      .post("/api/v1/csiArea/avgcsicell")
      .send(NullFilterRequest)
      .then((err, response) => {
        assert.equal(response.status, "400");
      });
    done();
  });

  it("Prefectures Test", (done) => {
    chai
      .request(server)
      .post("/api/v1/csiArea/data")
      .send(validFilterRequest)
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });

  it("Map Test", (done) => {
    chai
      .request(server)
      .post("/api/v1/csiArea/map")
      .send(validFilterRequest)
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });
});

