const constants = require("../locales/constants.js");
const dbUtil = require("../db/dbUtil.js");

function formKey(csiAvgKey, csiType, filterRequest) {
  var seperator = "_";
  var key = csiAvgKey.concat(seperator).concat(filterRequest.startDate);
  key = key.concat(seperator).concat(filterRequest.endDate);
  key = key.concat(seperator).concat(csiType.toLowerCase());
  key = key.concat(seperator).concat((filterRequest.region).toLowerCase()).concat(seperator);
  return key;
}

function getSubKey(csiType, filterRequest) {
  var seperator = "_";
  var key = (filterRequest.systemType.sort().join("##")).toLowerCase();
  if(constants.CSI_OVERALL === csiType){
    key = key.concat(seperator).concat(filterRequest.callDuration);
    key = key.concat(seperator).concat(filterRequest.dataVolume);
  }
  if(constants.CSI_VOICE === csiType){
    key = key.concat(seperator).concat(filterRequest.callDuration);
  }
  if(constants.CSI_DATA === csiType){
    key = key.concat(seperator).concat(filterRequest.dataVolume);
  }
  return key;
}

async function getCsiAvgData (csiType, filterRequest){

  var redisKey = formKey(constants.REDIS_KEY_AVG_CSI, csiType, filterRequest);
  var subKey = getSubKey(csiType, filterRequest);
  var result = [];
  var secKeyToFetchRealData = await dbUtil.getBucket(redisKey, subKey, filterRequest.isDemo);
  if (secKeyToFetchRealData) {
    var data = await dbUtil.getBucket(
      constants.VALUE_REDIS_KEY_AVG_CSI,
      secKeyToFetchRealData.value_key,
      filterRequest.isDemo
    );
    if (data) {
     result = data;
    }
  }
  return result;

}
module.exports = {
  getCsiAvgData,
  formKey,
};
