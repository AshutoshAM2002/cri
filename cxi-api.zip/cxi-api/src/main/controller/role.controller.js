const roleService = require("../service/role.service");

exports.findAll = async function (req, res) {
  res.send(await roleService.findAll());
};
