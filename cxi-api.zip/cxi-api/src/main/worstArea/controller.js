const service = require("./service.js");
const constants = require("../locales/constants.js");

const getRegionData = (req, res, next) => {
  var filterRequest = req.body.filterRequest;
  filterRequest.demo = req.header("demo");
  service
    .getDBResponse(constants.TABLE_DATA, filterRequest)
    .then((val) => {
      res.status(200).json({ data: val });
    })
    .catch((err) => next(err));
};

const getMapData = (req, res, next) => {
  var filterRequest = req.body.filterRequest;
  filterRequest.demo = req.header("demo");
  service
    .getDBResponse(constants.SITE_ID_DATA, filterRequest)
    .then((result) => {
      res.status(200).json({ data: result });
    })
    .catch((err) => next(err));
};

module.exports = { getRegionData, getMapData };
