const nodemailer = require("nodemailer");
const path = require("path");
const inlineCss = require("nodemailer-juice");
const fs = require("fs");
const constants = require("../locales/constants");

const transporter = nodemailer.createTransport({
  host: constants.SMTP_HOST,
  port: constants.SMTP_HOST,
  auth: {
    user: constants.SMTP_USER,
    pass: constants.SMTP_PASSWORD,
  },
});
const handlebars = require("handlebars");
exports.sendMail = async (from, to, subject, templateName , replace) => {
  const filepath = path.join(__dirname, "../template", templateName.concat(".html"));
  const source = fs.readFileSync(filepath, "utf-8").toString();
  const template = handlebars.compile(source);
  const htmlToSend = template(replace);
  const options = {
    applyAttributesTableElements: true,
    applyHeightAttributes: true,
    extraCss: true,
    url: "http://",
    inlinePseudoElements: true,
  };
  transporter.use("compile", inlineCss(options));

  await transporter.sendMail({
    from: from,
    to: to,
    subject: subject,
    html: htmlToSend,
    attachments: [
      {
        filename: "logo.png",
        path: path.join(__dirname, "../template", "logo.png"),
        cid: "logo.png", //same cid value as in the html img src
      },
    ],
  });
};


