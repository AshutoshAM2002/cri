process.env.NODE_ENV = "test";
const assert = require("chai").assert;
const plmService = require("../main/plm/service.js");

const repo = require("../main/db/repo.js");
let sinon = require("sinon");
var path = require("path");
var file = path.join(__dirname, "./resource/plm.json");

describe("plmService.service.js", () => {
  let filterRequest = {
    startDate: "20211213",
    endDate: "20211213",
    systemType: "LTE",
  };
  let getStub;
  let disconnectStub;
  beforeEach(() => {
    getStub = sinon.stub(repo, "get");
    disconnectStub = sinon.stub(repo, "isDBConnected");
    disconnectStub.returns(true);
    getAllStub = sinon.stub(repo, "getAll");
  });
  afterEach(() => {
    disconnectStub.restore();
    getAllStub.restore();
    getStub.restore();
  });
  it("plmService.formKey()", () => {
    const response = plmService.formKey("CSI_OVERALL", filterRequest);
    assert.isNotEmpty(response);
  });

  it("plmService.getDataForCsi()", () => {
    filterRequest.demo = true;
    getAllStub.usingPromise().resolves(require(file));
    const response = plmService.getDataForCsi("CSI_OVERALL", filterRequest);
  });
});
