const express = require("express");
const router = express.Router();

const controller = require("./controller.js");

router.post("/data", controller.getRegionData);
router.post("/map", controller.getMapData);


module.exports = router;
