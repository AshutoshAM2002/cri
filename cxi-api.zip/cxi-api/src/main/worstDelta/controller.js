const service = require("./service.js");
const constants = require("../locales/constants.js");

const getRegionData = (req, res, next) => {
  var filterRequest = req.body.filterRequest;
  filterRequest.demo = req.header("demo");
  service
    .getData(constants.TABLE_DATA, filterRequest)
    .then((val) => {
      res.status(200).json({ data: val });
    })
    .catch((err) => next(err));
};

const getMapData = (req, res, next) => {
  var filterRequest = req.body.filterRequest;
  filterRequest.demo = req.header("demo");
  service
    .getData(constants.SITE_ID_DATA, filterRequest)
    .then((result) => {
      res.status(200).json({ data: result });
    })
    .catch((err) => next(err));
};

const getChartData = (req, res, next) => {
  var filterRequest = req.body.filterRequest;
  filterRequest.demo = req.header("demo");
  service
    .getData(constants.CHART_DATA, filterRequest)
    .then((result) => {
      res.status(200).json({ data: result });
    })
    .catch((err) => next(err));
};


module.exports = { getRegionData, getMapData, getChartData};
