const jwt = require("jsonwebtoken");
const { secret } = require("../config.json");
const ApiError = require("../middlewares/error/ApiError");

module.exports = verifyToken;

function verifyToken(req, res, next) {
  let token = req.headers["authorization"]
    ? req.headers["authorization"].split(" ")[1]
    : null;
  if (!token) return next(ApiError.forbidden("Access Forbidden."));

  jwt.verify(
    token,
    secret,
    { issuer: req.protocol + "://" + req.get("host") },
    function (err, decoded) {
      if (err) next(ApiError.forbidden("Access Forbidden."));
      next();
    }
  );
}
