const config = require("../config/db.config.js");
const Sequelize = require("sequelize");
const sequelize = new Sequelize(config.DB, config.USER, config.PASSWORD, {
  host: config.HOST,
  dialect: config.dialect,
  operatorsAliases: false,
  define:{
    freezeTableName: true,
    timestamps: false,
  },
  pool: {
    max: config.pool.max,
    min: config.pool.min,
    acquire: config.pool.acquire,
    idle: config.pool.idle,
  },
});
const db = {};
db.Sequelize = Sequelize;
db.sequelize = sequelize;
db.user = require("./user.model.js")(sequelize, Sequelize);
db.role = require("./role.model.js")(sequelize, Sequelize);
db.userRole = require("./user_role.model.js")(sequelize, Sequelize);
db.alert = require("./alert.model.js")(sequelize, Sequelize);
db.alertImages = require("./alert_images.model.js")(sequelize, Sequelize);

db.user.belongsToMany(db.role, {
  through: db.userRole,
  as: "roles",
  foreignKey: "user_id",
});
db.role.belongsToMany(db.user, {
  through: db.userRole,
  as: "users",
  foreignKey: "role_id",
});

db.alert.hasMany(db.alertImages, {as : "images"});
db.alertImages.belongsTo(db.alert, {
  foreignKey: "alert_id",
  as : "alert",
});

module.exports = db;
