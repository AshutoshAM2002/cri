const cache = require("../cache/cache.js");
const repo = require("../db/repo.js");
const util = require("./util.js");
const logger = require("../middlewares/logger/logger.js");
const constants = require("../locales/constants.js");
const ApiError = require("../middlewares/error/ApiError.js");

var REDIS_KEY_MAP_REGION = constants.REDIS_KEY_MAP_REGION;
const seperator = "_";

const getCoreKPIData = async function (filterRequest) {
  try {
    var field = filterRequest.startDate + seperator + filterRequest.endDate;
    var result = getData(
      constants.REDIS_KEY_CORE_KPI,
      field,
      filterRequest.demo
    );
    return sortCoreKPIResponse(result, "region");
  } catch (err) {
    throw err;
  }
};

const getPrefecturesForRegion = async function (filterRequest) {
  try {
    var field = formMapKey(filterRequest);
    var result = getData(
      constants.REDIS_KEY_CSI_DATA,
      field,
      filterRequest.demo
    );

    var res = {};
    var data = sortData(result, "name");
    await data.then((val) => {
      res.result = val;
    });

    var id = "region";
    id = filterRequest.region != "ALL" ? (id = "prefecture") : id;
    id = filterRequest.prefecture ? (id = "dimos") : id;
    id = filterRequest.dimos ? (id = "siteId") : id;
    res.id = id;
    return res;
  } catch (err) {
    throw err;
  }
};

const getCellData = async function (filterRequest) {
  try {
    var field = formMapKey(filterRequest);
    var result = getData(
      constants.REDIS_KEY_DOCX_AVG_CSI,
      field,
      filterRequest.demo
    );
    return sortSiteIdResponse(result);
  } catch (err) {
    throw err;
  }
};

const getMapData = async function (filterRequest) {
  var csiDataKey = constants.REDIS_KEY_CSI_DATA;
  if (filterRequest.demo === "true") {
    csiDataKey = constants.REDIS_KEY_CSI_DATA + "_demo";
  }
  var baseData = await repo.get(
    REDIS_KEY_MAP_REGION,
    formGeoJsonKey(filterRequest)
  );
  var csiData = await repo.getObject(
    csiDataKey.toLowerCase() + formMapKey(filterRequest).toLowerCase()
  );
  if (baseData && csiData) {
    baseData.features.forEach((feature) => {
      if (feature && feature.properties) {
        var csi = getCsiData(feature.properties.code, csiData);
        if (csi) {
          feature.properties["csi_average"] = csi["csi_average"];
        } else {
          feature.properties["csi_average"] = -1;
        }
      }
    });
  }

  return baseData;
};

function getCsiData(code, csiArray) {
  var csiData = csiArray.filter((csi) => {
    return csi.name == code;
  })[0];
  return csiData;
}

function formGeoJsonKey(filterRequest) {
  var seperator = ":";
  var key = "ALL";
  if (filterRequest.region) {
    key = filterRequest.region;
  }

  if (filterRequest.prefecture)
    key = key.concat(seperator).concat(filterRequest.prefecture);

  if (filterRequest.dimos)
    key = key.concat(seperator).concat(filterRequest.dimos);
  return key;
}

function formMapKey(filterRequest) {
  var defaultRegionKey = "ALL";
  var defaultSystemTypeKey = "LTE";
  let defaultCoreKpi = "csi_overall";
  var key = filterRequest.startDate + seperator + filterRequest.endDate;
  filterRequest.systemType
    ? (key = key.concat(seperator).concat(filterRequest.systemType))
    : (key = key.concat(seperator).concat(defaultSystemTypeKey));

  filterRequest.coreKPI
    ? (key = key.concat(seperator).concat(filterRequest.coreKPI))
    : (key = key.concat(seperator).concat(defaultCoreKpi));

  filterRequest.region
    ? (key = key.concat(seperator).concat(filterRequest.region))
    : (key = key.concat(seperator).concat(defaultRegionKey));
  filterRequest.prefecture
    ? (key = key.concat(seperator).concat(filterRequest.prefecture))
    : (key = key.concat(seperator).concat(defaultRegionKey));
  filterRequest.dimos
    ? (key = key.concat(seperator).concat(filterRequest.dimos))
    : (key = key.concat(seperator).concat(defaultRegionKey));
  return key;
}

const getData = async function (bastionKey, field, isDemo) {
  let key = bastionKey.toLowerCase() + field.toLowerCase();
  try {
    if (isDemo === "true") {
      key = key.concat("_demo");
    }
    var cacheResponse = await cache.getCacheObject(key);
    if (cacheResponse) {
      return JSON.parse(cacheResponse);
    }
    if (repo.isDBConnected()) {
      return repo.getObject(key);
    }
    throw ApiError.internal(
      "Unable to Process your request due to server is down, Please try after some time."
    );
  } catch (error) {
    logger.error(error);
    if (error instanceof ApiError) throw error;
  }
};

module.exports = {
  getCoreKPIData,
  getPrefecturesForRegion,
  getCellData,
  getData,
  getMapData,
};

function sortData(data, key) {
  if (data instanceof Promise) {
    data.then((val) => {
      if (Array.isArray(val)) {
        val.sort((a, b) => util.sortData(a, b, key));
      }
    });
  }
  return data;
}

function sortSiteIdResponse(data) {
  data.then((val) => {
    if (Array.isArray(val)) {
      val.sort(util.compareSiteIds);
    }
  });
  return data;
}

function sortCoreKPIResponse(data, key) {
  data.then((val) => {
    if (val != undefined && val != null && val != "ECONNREFUSED") {
      val[0].region_details.sort((a, b) => util.sortData(a, b, key));
      val[1].region_details.sort((a, b) => util.sortData(a, b, key));
    }
  });
  return data;
}
