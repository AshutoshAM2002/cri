const mailService = require("../service/mail.service");
const constants = require("../locales/constants");
exports.sendMail = async (req, res) => {
  await mailService.sendMail(
    constants.FROM_MAIL_ID,
    req.query.emailId,
    constants.INVITATION_SUBJECT,
    req.query.template,
    { recipientEmail: req.params.emailId }
  );
  res.send(true);
};
