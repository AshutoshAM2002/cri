function sortData(a, b, key) {
  if (a[key] < b[key]) {
    return -1;
  }
  if (a[key] > b[key]) {
    return 1;
  }
  return 0;
}

function compareSiteIds(a, b) {
  let id1 = parseInt(a.site_id);
  let id2 = parseInt(b.site_id);
  if (id1 < id2) {
    return -1;
  }
  if (id1 > id2) {
    return 1;
  }
  return 0;
}

module.exports = {compareSiteIds, sortData };
