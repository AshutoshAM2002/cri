const jwt = require("jsonwebtoken");

async function basicAuth(req,res,next) {

    // check for basic auth header
    const bearerHeader = req.headers.authorization;

    if (!bearerHeader || bearerHeader.indexOf('Bearer ') === -1) {
        return res.status(401).json({ "status":401, message:'Unauthorize', description: 'Missing Authorization Header' });
    }
    if (typeof bearerHeader !== undefined){
        const bearerToken = bearerHeader.split(" ")[1];
        jwt.verify(bearerToken,'secret',(err,authData) =>{
            if(err){
                res.sendStatus(403);
            }
            else{
                next();
            }
        })

    }

}

module.exports = basicAuth;
