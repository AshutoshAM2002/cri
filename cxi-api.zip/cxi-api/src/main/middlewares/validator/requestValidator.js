// helper functions
const logger = require("../logger/logger.js");
const ApiError = require("../error/ApiError");
// File upload Validation
const multer = require("multer");
const constants = require("../../locales/constants.js");
const allowdFormats = new Set(["image/png", "image/jpg", "image/jpeg"]);

// helper functions
const Joi = require("joi");
const validateRequest = function (req, next, schema) {
  const options = {
    abortEarly: false, // include all errors
    allowUnknown: true, // ignore unknown props
    stripUnknown: true, // remove unknown props
  };
  const { error, value } = schema.validate(req.body, options);
  if (error) {
    logger.error(
      `Validation error: ${error.details.map((x) => x.message).join(", ")}`
    );
    error.name = "ValidationError";
    error.errors = error.details;
    next(error);
  } else {
    req.body = value;

    if (req.body.filterRequest === undefined) {
      next(
        ApiError.badRequest(
          "Payload is null, please send with required details."
        )
      );
    }
    next();
  }
};

const validateCreateUserRequest = function (req, res, next) {
  const schema = Joi.array()
    .items({
      firstName: Joi.string().required(),
      lastName: Joi.string().required(),
      roles: Joi.array()
        .items({
          id: Joi.number().integer().required(),
        })
        .required(),
      isActive: Joi.boolean().required(),
      email: Joi.string().required(),
    })
    .required();

  validate(req.body, next, schema);
};

const validate = function (payload, next, schema) {
  const options = {
    abortEarly: false, // include all errors
    allowUnknown: true, // ignore unknown props
    stripUnknown: true, // remove unknown props
  };
  const { error } = schema.validate(payload, options);

  if (error) {
    logger.error(
      `Validation error: ${error.details.map((x) => x.message).join(", ")}`
    );
    error.name = "ValidationError";
    error.errors = error.details;
    next(error);
  }
  next();
};

const validateAlertRequest = function (req, res, next) {
  let payload = JSON.parse(req.body.payload);
  const schema = Joi.object().keys({
    region: Joi.string().required(),
    prefecture: Joi.string().required(),
    dimos: Joi.string().required(),
    site: Joi.string().required(),
    title: Joi.string().required(),
    description: Joi.string().required(),
    kpi: Joi.string().required(),
    systemType: Joi.string().required(),
    startDate: Joi.date().required(),
    endDate: Joi.date().required(),
    priority: Joi.string().required(),
    csiValue: Joi.number().integer().required(),
  });
  validate(payload, next, schema);
};

const validateGetAlertsRequest = function (req, res, next) {
  const schema = Joi.object().keys({
    region: Joi.string().required(),
    systemType: Joi.string().required(),
    startDate: Joi.date().required(),
    endDate: Joi.date().required(),
    csiValue: Joi.number().integer().required(),
  });
  validate(req.body, next, schema);
};

// Validate File format using multer middleware.
const imageFilter = (req, file, cb) => {
  if (allowdFormats.has(file.mimetype)) {
    cb(null, true);
  } else {
    cb(
      ApiError.badRequest(
        "Please upload only images of JPEG, JPG & PNG format."
      ),
      false
    );
  }
};

const validateShareAlert = function (req, res, next) {
  const schema = Joi.array().items({
    email: Joi.string().required(),
  });
  validate(req.body, next, schema);
};

var uploadFile = multer({
  fileFilter: imageFilter,
  limits: { fileSize: constants.MAX_FILE_SIZE },
});
module.exports = {
  validateRequest,
  validateCreateUserRequest,
  validateAlertRequest,
  uploadFile,
  validateGetAlertsRequest,
  validateShareAlert,
};
