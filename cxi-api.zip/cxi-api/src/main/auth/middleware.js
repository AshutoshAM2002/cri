const ApiError = require("../middlewares/error/ApiError");
const logger = require('../middlewares/logger/logger.js');
const validateRequest = function(req,res,next){

    const {username, password} = req.body;
    if(isDataPresent(username,password)){
        next()
    }
    else{
        logger.info("User has entered invalid credentials.");
        next(ApiError.unAuthorize("Please enter valid credentials!!"));
    }
}

function isDataPresent(userid,pass){
    let isPresent = true;
    if(!userid || !pass){
        isPresent = false;
    }
    return isPresent;
}
module.exports = {validateRequest};