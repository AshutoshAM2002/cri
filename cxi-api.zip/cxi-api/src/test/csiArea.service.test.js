process.env.NODE_ENV = "test";
const assert = require("chai").assert;
const csiAreaService = require("../main/csiArea/service.js");
const repo = require("../main/db/repo.js");
let sinon = require("sinon");
var path = require("path");
var avgCellData = path.join(__dirname, "./resource/csiAreaCellData.json");
var baseData = path.join(__dirname, "./resource/baseData.json");

let filterRequest = {
  startDate: "20211207",
  endDate: "20211213",
  region: "ALL",
  systemType: "LTE",
};
let filterRequestForCell = {
  startDate: "20211207",
  endDate: "20211213",
  region: "ATH",
  systemType: "LTE",
  prefecture: "ATHN",
  dimos: "AGION ANARGURON - KAMATEROU",
};

describe("csiArea.service.js", () => {
  let getStub;
  let disconnectStub;
  beforeEach(() => {
    getStub = sinon.stub(repo, "get");
    disconnectStub = sinon.stub(repo, "isDBConnected");
    disconnectStub.returns(true);
  });
  afterEach(() => {
    disconnectStub.restore();
    getStub.resetBehavior();
    getStub.restore();
  });
  it("Stub csiAreaService.getCellData ()", () => {
    getStub.usingPromise().resolves(require(avgCellData));
    const response = csiAreaService.getCellData(filterRequestForCell);
    response.then((val) => {
      assert.isNotEmpty(val);
    });
  });

  it("csiAreaService.getPrefecturesForRegion ()", () => {
    filterRequest.demo = true;
    const response = csiAreaService.getPrefecturesForRegion(filterRequest);
    response.then((val) => {
      assert.isNotEmpty(val);
    });
  });

  it("csiAreaService.getCoreKPIData ()", (done) => {
    const response = csiAreaService.getCoreKPIData(filterRequest);
    response.then((val) => {
      assert.isNotEmpty(val);
    });
    done();
  });

  it("csiAreaService.getMapData ()", () => {
    getStub
      .onFirstCall()
      .returns(require(baseData))
      .onSecondCall()
      .returns(require(avgCellData));
    filterRequestForCell.demo = true;
    const response = csiAreaService.getMapData(filterRequestForCell);
    response.then((val) => {
      assert.isNotEmpty(val);
    });
  });
});
