const constants = require("../locales/constants.js");
const dbUtil = require("../db/dbUtil.js");
function getSubKey(filterRequest) {
  let seperator = ":";
  let key = "";

  if (filterRequest.type == "prefecture") {
    key = "prefecture";
  }

  if (filterRequest.type == "cell") {
    key = "cellname";
  }

  if (filterRequest.type == "dimos") {
    key = "dimos_kallikr";
  }

  if (filterRequest.type == "site") {
    key = "site_name";
  }

  key = key.concat(seperator).concat(filterRequest.searchText.substring(0, 3));

  return key;
}

async function search(filterRequest) {
  let redisKey = constants.SEARCH_LOCATION;

  let subKey = getSubKey(filterRequest);
  let result = [];
  let data = await dbUtil.getData(redisKey, subKey, filterRequest.isDemo);

  if (data) {
    result = data.filter((element) => {
      return element["name"].includes(filterRequest.searchText);
    });
  }

  return result.slice(0, 25);
}

async function chartData(filterRequest) {
  let result = [];
  if (filterRequest.locations) {
    for (let location of filterRequest.locations) {
      let key = formLocationKey(
        filterRequest,
        constants.KEY_LOCATION_DATA,
        location
      )
        .concat("_")
        .concat(formSecondaryKey(filterRequest));
      let keyData = await dbUtil.getBucket(key, filterRequest.isDemo);
      let dataSecondaryKey = formLocationKey(
        filterRequest,
        constants.VALUE_LOCATION_DATA,
        location
      )
        .concat("_")
        .concat(keyData["value_key"]);

      let data = await dbUtil.getBucket(dataSecondaryKey, filterRequest.isDemo);
      if (data && data != 'NO DATA') {
        let val = { location: location, data: data };
        result.push(val);
      }
    }

    return result;
  }
}

function formLocationKey(filterRequest, key, location) {
  let seperator = "_";
  if (filterRequest.startDate)
    key = key.concat(seperator).concat(filterRequest.startDate);

  if (filterRequest.endDate)
    key = key.concat(seperator).concat(filterRequest.endDate);

  if (filterRequest.coreKPI)
    key = key.concat(seperator).concat(filterRequest.coreKPI);

  if (location) key = key.concat(seperator).concat(location.toLowerCase());

  return key;
}

function formSecondaryKey(filterRequest) {
  let seperator = "_";
  let key = filterRequest.systemType.sort().join("##");

  if (
    filterRequest.coreKPI == "csi_overall" ||
    filterRequest.coreKPI == "csi_voice"
  )
    key = key.concat(seperator).concat(filterRequest.callDuration);

  if (
    filterRequest.coreKPI == "csi_overall" ||
    filterRequest.coreKPI == "csi_data"
  )
    key = key.concat(seperator).concat(filterRequest.dataVolume);

  return key;
}
module.exports = {
  search,
  chartData,
};
