process.env.NODE_ENV = "test";

const server = require("../main/app");
const chai = require("chai");
const chaiHttp = require("chai-http");
const repo = require("../main/db/repo.js");
let sinon = require('sinon');
var path = require("path");
var file = path.join(__dirname, "./resource/plm.json");

//Assertion
chai.should();
chai.use(chaiHttp);

const assert = chai.assert;

describe("PLM API", () => {
  let getStub;
  let disconnectStub;
  let getAllStub;

  beforeEach(()=>{
    getStub = sinon.stub(repo, "get");
    disconnectStub = sinon.stub(repo, "isDBConnected");
    getAllStub = sinon.stub(repo, "getAll");
    disconnectStub.returns(true)
  });
  afterEach(() => {
    disconnectStub.restore();
    getStub.restore();
    getAllStub.restore()
  });

  let validFilterRequest = {
    filterRequest : {
      startDate: "20211213",
      endDate: "20211213",
      systemType: "LTE"
  }
};
it("PLM API Overall", (done) => {

    getAllStub.usingPromise().resolves(require(file));
    chai
      .request(server)
      .post("/api/v1/plm/csiOverall")
      .send(validFilterRequest)
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });

  it("PLM API Voice", (done) => {
    validFilterRequest.csiType = "voice";
    chai
      .request(server)
      .post("/api/v1/plm/csiVoice")
      .send(validFilterRequest)
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });

  it("PLM API Data", (done) => {
    validFilterRequest.csiType = "data";
    chai
      .request(server)
      .post("/api/v1/plm/csiData")
      .send(validFilterRequest)
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });
});
