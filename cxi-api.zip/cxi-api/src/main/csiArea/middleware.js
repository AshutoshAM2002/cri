
const ApiError = require("../middlewares/error/ApiError");
const validateFilterRequest = function(req,res,next){

    const filterRequest = req.body.filterRequest;
    if(isDataPresent(filterRequest)){
        next()
    }
    else{
        next(ApiError.badRequest('Bad Request'));  
    }
}

function isDataPresent(filterRequest){
    if(filterRequest === undefined || filterRequest === "null"){
        return false;
    }
    if(filterRequest.startDate === "" || filterRequest.endDate === undefined){
        return false;
    }
    return true;
}
module.exports = {validateFilterRequest};