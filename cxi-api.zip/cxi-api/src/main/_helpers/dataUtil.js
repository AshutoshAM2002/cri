function sendData(dbResponse, key) {
  if (dbResponse) {
    return dbResponse[key];
  }
  return [];
}
  
module.exports = { sendData };
