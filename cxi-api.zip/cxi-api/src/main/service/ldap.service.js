const ldap = require("ldapjs");
const constants = require("../locales/constants");

exports.searchUsers = async (criteria) => {
  try {
    return new Promise(function (resolve, reject) {
      const opts = {
        filter: "("
          .concat(constants.LDAP_BASE_UID)
          .concat(criteria)
          .concat("*)"),
        scope: "sub",
        attributes: constants.LDAP_ATTRIBUTE,
      };

      const client = ldap.createClient({
        url: [constants.LDAP_BASE_URL],
      });

      client.bind(
        constants.LDAP_ADMIN_DN,
        constants.LDAP_PASSWORD,
        function (err) {
          if (err) console.log(err);
          else {
            let users = [];
            client.search(constants.LDAP_BASE_SEARCH, opts, (error, resp) => {
              resp.on("searchEntry", (entry) => {
                if (entry) {
                  users.push(setUserObject(entry.object));
                }
              });
              resp.on("end", () => {
                resolve(users);
              });
              resp.on("error", () => {
                logger.error("Error " + err);
                reject(err);
              });
            });
          }
        }
      );
    });
  } catch (err) {
    res.status(500).send({
      message: err.message || "Some error occurred while retrieving roles.",
    });
  }
};

function setUserObject(entry) {
  let names = entry[constants.LDAP_KEY_NAME].split(" ");
  return {
    firstName: names.length > 0 ? names[0] : entry[constants.LDAP_KEY_NAME],
    lastName: names.length > 1 ? names[1] : entry[constants.LDAP_KEY_NAME],
    name: entry[constants.LDAP_KEY_NAME],
    userName: entry[constants.LDAP_KEY_USERNAME],
    email: entry[constants.LDAP_KEY_EMAIL],
  };
}
