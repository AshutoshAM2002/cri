const express = require("express");
const router = express.Router();

const avgCsiController = require("./controller.js");
const middleware = require("./middleware.js");

router.post("/csiOverall", middleware.createFilterSchema, avgCsiController.getCsiOverall);
router.post("/csiVoice", middleware.createFilterSchema, avgCsiController.getCsiVoice);
router.post("/csiData", middleware.createFilterSchema, avgCsiController.getCsiData);
module.exports = router;