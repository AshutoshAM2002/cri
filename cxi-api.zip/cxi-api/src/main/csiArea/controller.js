const service = require("./service.js");

const getAvgCSIPerCellId = (req, res, next) => {
  var filterRequest = req.body.filterRequest;
  filterRequest.demo = req.header("demo");
  let apiResponse = service.getCellData(filterRequest);
  sendResponse(apiResponse, res, next);
};

const getCoreKPIData = (req, res, next) => {
  var filterRequest = req.body.filterRequest;
  filterRequest.demo = req.header("demo");
  let apiResponse = service.getCoreKPIData(filterRequest, next);
  sendResponse(apiResponse, res, next);
};

const getPrefectureData = (req, res, next) => {
  var filterRequest = req.body.filterRequest;
  filterRequest.demo = req.header("demo");
  let apiResponse = service.getPrefecturesForRegion(filterRequest);
  sendResponse(apiResponse, res, next);
};

const getMapData = (req, res, next) => {
  var filterRequest = req.body.filterRequest;
  filterRequest.demo = req.header("demo");
  let apiResponse = service.getMapData(filterRequest);
  sendResponse(apiResponse, res, next);
};

const sendResponse = (apiResponse, res, next) => {
  if (apiResponse instanceof Promise) {
    apiResponse.then((val) => {
      res.status(200).json({
        data: val,
      });
    }).catch(err=>next(err));
  }
};

module.exports = {
  getAvgCSIPerCellId,
  getCoreKPIData,
  getPrefectureData,
  getMapData,
};
