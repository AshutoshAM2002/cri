const express = require("express");
const router = express.Router();

const controller = require("./controller.js");
const middleware = require("./middleware.js");

router.post("/data", middleware.createFilterSchema, controller.getRegionData);
router.post("/map", middleware.createFilterSchema,controller.getMapData);
router.post("/chart", middleware.createFilterSchema,controller.getChartData);

module.exports = router;
