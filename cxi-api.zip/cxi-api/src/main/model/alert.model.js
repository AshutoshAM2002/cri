const { Sequelize } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  return sequelize.define("alert", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    title: {
      type: DataTypes.STRING,
      field: "title",
    },
    description: {
      type: DataTypes.STRING,
      field: "description",
    },
    priorityValue: {
      type: DataTypes.INTEGER,
      field: "priority_value",
    },
    priority: {
      type: DataTypes.STRING,
      field: "priority",
    },
    status: {
      type: DataTypes.STRING,
      field: "status",
    },
    region: {
      type: DataTypes.STRING,
    },
    prefecture: {
      type: DataTypes.STRING,
    },
    dimos: {
      type: DataTypes.STRING,
    },
    site: {
      type: DataTypes.STRING,
    },
    systemType: {
      type: DataTypes.STRING,
      field: "system_type",
    },
    kpi: {
      type: DataTypes.STRING,
    },
    createdBy: {
      type: DataTypes.STRING,
      field: "created_by",
    },
    createdDate: {
      type: Sequelize.DATEONLY,
      field: "created_date",
    },
    startDate: {
      type: Sequelize.DATEONLY,
      field: "start_date",
    },
    endDate: {
      type: Sequelize.DATEONLY,
      field: "end_date",
    },
    csiValue: {
      type: DataTypes.INTEGER,
      field: "csi_value",
    },
  });
};
