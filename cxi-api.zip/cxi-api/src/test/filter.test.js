process.env.NODE_ENV = "test";

const server = require("../main/app");
const chai = require("chai");
const chaiHttp = require("chai-http");
//Assertion
chai.should();
chai.use(chaiHttp);

const assert = chai.assert;

describe("Filter Panel API", () => {
  it("Filter Values", (done) => {
    chai
      .request(server)
       .get("/api/v1/filters")
      .then((err, response) => {
        assert.isNotEmpty(response);
        response.should.have.status(200);
      });
    done();
  });
});
