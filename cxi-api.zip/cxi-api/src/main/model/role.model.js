module.exports = (sequelize, DataTypes) => {
  return sequelize.define("role", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
    },
    roleCode: {
      type: DataTypes.STRING,
      field: "role_code",
    },
    roleName: {
      type: DataTypes.STRING,
      field: "role_name",
    },
    description: {
      type: DataTypes.STRING,
    },
    access: {
      type: DataTypes.STRING,
    },
  });
};
